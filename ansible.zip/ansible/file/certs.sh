#!/bin/bash 
vaultname="$1"
echo "vaultname=$1"
reffolder="$2"
echo "reffolder=$2"
filename="$3"
echo "filename=$3"
IFS=","
while read name crtname
do
echo "name of the orderer/peer cert: $name"
echo "certificatename: $crtname" 
crtname1="$(echo "${crtname}" | tr -d '[[:space:]]')"
echo "$crtname1"
output="$(find $reffolder -type f -name "$crtname1"| head -n 1)"
if [ -z "$output" ]
then
    echo " exiting because "$crtname1" not found in folders"
    exit 1
else 
    my_array="$(find $reffolder -type f -name "$crtname1"| head -n 1)"
    echo "$my_array" | while IFS= read -r line ;
    do
      echo az keyvault secret set --vault-name "$vaultname" --name "$name" --file "'$line'"
    if eval az keyvault secret set --vault-name "$vaultname" --name "$name" --file "'$line'"
    then 
        echo "command success for $line"
    else
        echo "command failed for $line" 
        exit 1
    fi
    done  
fi
done < $filename
