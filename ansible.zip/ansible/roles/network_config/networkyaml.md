
## Secret variable update in Azure Library/Vault and use in pipeline variable group. 
```
    - DEPLOY_KEY_FILE: "{{ lookup('env', 'DEPLOY_KEY') }}"
    - KEY_VAULT_NAME: "{{ lookup('env', 'KEY_VAULT_NAME') }}" 
    - ARM_CLIENT_ID_FILE: "{{ lookup('env', 'ARM_CLIENT_ID_KEY') }}" 
    - ARM_CLIENT_SECRET_FILE: "{{ lookup('env', 'ARM_CLIENT_SECRET_KEY') }}"
    - ARM_TENANT_ID_FILE: "{{ lookup('env', 'ARM_TENANT_ID_KEY') }}"
    - branch_name: "{{ lookup('env', 'branch_name') }}"
    - SUBSCRIPTION_ID: "{{ lookup('env', 'SUBSCRIPTION_ID') }}"
    - REGION: "{{ lookup('env', 'REGION') }}"
    - KUBE_CONTEXT: "{{ lookup('env', 'KUBE_CONTEXT') }}"
    - KUBE_CONFIG: "{{ lookup('env', 'KUBE_CONFIG') }}"
    - BAF_BRANCH: "{{ lookup('env', 'BAF_BRANCH') }}"
    - GIT_USER: "{{ lookup('env', 'GIT_USER') }}"
    - GIT_PASSWD: "{{ lookup('env', 'GIT_PASSWD') }}"
    - EMAIL_ID: "{{ lookup('env', 'EMAIL_ID') }}"
    - PRIVATE_KEY: "{{ lookup('env', 'PRIVATE_KEY') }}"
    - AWS_ACCESS_KEY: "{{ lookup('env', 'AWS_ACCESS_KEY') }}"
    - AWS_SECRET_KEY: "{{ lookup('env', 'AWS_SECRET_KEY') }}"
```
  
The snapshot of the `env` section with example value is below
```yaml 
  env:
    type: "{{env_type}}"              # tag for the environment. Important to run multiple flux on single cluster
    proxy: haproxy                  # values can be 'haproxy' or 'ambassador'
    ambassadorPorts: 15010,15020    # Any additional Ambassador ports can be given here, must be comma-separated without spaces, this is valid only if proxy='ambassador'
    loadBalancerSourceRanges: # (Optional) Default value is '0.0.0.0/0', this value can be changed to any other IP adres or list (comma-separated without spaces) of IP adresses, this is valid only if proxy='ambassador'
    retry_count: 30                 # Retry count for the checks
    external_dns: {{external_dns}}            # Should be enabled if using external-dns for automatic route configuration
    annotations:              # Additional annotations that can be used for some pods (ca, ca-tools, orderer and peer nodes)
      service: 
       - example1: example2
      deployment: {} 
      pvc: {}
```



`orderers` section contains a list of orderers with variables which will expose it for the network.

The snapshot of the `orderers` section with example values is below
```yaml
  # Remote connection information for orderer (will be blank or removed for orderer hosting organization)
  orderers:
    - orderer:
      type: orderer
      name: orderer1
      org_name: supplychain               #org_name should match one organization definition below in organizations: key            
      uri: orderer1.org1ambassador.blockchaincloudpoc.com:8443   # Can be external or internal URI for orderer which should be reachable by all peers
      certificate: /home/bevel/build/orderer1.crt           # Ensure that the directory exists
    - orderer:
      type: orderer
      name: orderer2
      org_name: supplychain               #org_name should match one organization definition below in organizations: key            
      uri: orderer2.org1ambassador.blockchaincloudpoc.com:8443   # Can be external or internal URI for orderer which should be reachable by all peers
      certificate: /home/bevel/build/orderer2.crt           # Ensure that the directory exists
```

The `channels` sections contains the list of channels mentioning the participating peers of the organizations.

The snapshot of channels section with its fields and sample values is below

```yaml
    # The channels defined for a network with participating peers in each channel
  - channel:
    consortium: eZTrackerConsortium
    channel_name: zp-merck-channel
    orderer: 
      name: zporderer
    {{ particiates_list }}
    endorsers:
    {{ endorsers_list }}
    
    genesis:
      name: OrdererGenesis
```


The `organizations` section contains the specifications of each organization.  

In the sample configuration example, we have five organization under the `organizations` section

The snapshot of an organization field with sample values is below
```yaml
  organizations:
    # Specification for the 1st organization. Each organization maps to a VPC and a separate k8s cluster
  - organization:
    name: {{org_name}}
    country: {{country}}
    state: {{state}}
    location: {{location}}
    subject: "O=Orderer,L=51.50/-0.13/London,C=GB"
    type: orderer
    external_url_suffix: dev.mulitenant.zuelligpharma.com
    org_status: {{org_status}}
    tenant_type: {{tenant_type}}
    fabric_ca : disabled                  # check if fabric CA is enabled or disabled
    cli: enabled
    ca_data:
      url: ca.zporderer-net:7054
      certificate: file/server.crt        # This has not been implemented in 0.2.0.0
```
For the aws and k8s field the snapshot with sample values is below
```yaml
    cloud_provider: azure   # Options: aws, azure, gcp, minikube
    aws:
      aws_access_key: {{aws_access_key}}
      aws_secret_key: {{aws_secret_key}}
    # Kubernetes cluster deployment variables. The config file path and name has to be provided in case
    # the cluster has already been created.
    k8s:
     region: {{region}}
     context: {{context}}
     config_file: {{config_file}}
    # Hashicorp Vault server address and root-token. Vault should be unsealed.
    # Do not check-in root_token
    akv: 
     secretRef: {{secretRef}}
     keyvaultname: {{keyvaultname}}
     clientid: {{clientid}}
     clientsecret: {{clientsecret}}
     resourcegroup: {{resourcegroup}}
     subscriptionid: {{subscriptionid}}
     tenantid: {{tenantid}}
```
                                                          |

For gitops fields the snapshot from the sample configuration file with the example values is below
```yaml
      # Git Repo details which will be used by GitOps/Flux.
      gitops: #https://dev.azure.com/zuelligpharmadevops/eZTracker_V2/_git/eZTracker-baf-mulitenant
        git_protocol: "ssh" # Option for git over https or ssh
        git_url: {{git_url}}         # Gitops ssh url for flux value files 
        branch: {{branch}}           # Git branch where release is being made
        release_dir: {{release_dir}} # Relative Path in the Git repo for flux sync per environment. 
        chart_source: {{chart_source}}     # Relative Path where the Helm charts are stored in Git repo
        git_repo: {{git_repo}}  # Gitops https URL for git push  (without https://) 
        username: {{username}}         # Git Service user who has rights to check-in in all branches
        password: {{password}}         # Git Server user password
        email: {{email}}               # Email to use in git config
        private_key: {{private_key}}  
```

Info: https://blockchain-automation-framework.readthedocs.io/en/latest/operations/fabric_networkyaml.html 
