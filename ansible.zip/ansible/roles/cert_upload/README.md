Role Name
=========
This is a role to upload certificates into azure key vault

Requirements
------------
Before running this role,make sure you have certificate folder,where all the organisations certificates present there.

Role Variables
--------------
All variables will be placed under group_vars  folder
provide vaultname to which you want to upload ex:vault_name:sandbox
provide path for directory structure where you placed all the directory structure ex:ref_folder:/home/azureuser/reffolder
provide csv file where you listed required certificate names will be present ex:file_name: sample.csv

Dependencies
------------
make sure you added your vm ip in key vault networking section
make sure you have permission to upload certificates
make sure you logged into azure cli with your account that you have added in keyvault.
make sure shell script and csv file in files folder that is in roles folder
all input and output files will be placed under "file" folder


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
        - cert_upload

