#!/bin/bash
filename="$1"
echo "filename=$1"
IFS=","
while read RGName VMName
do
echo "name of the ResourceGroup: $RGName"
echo "SericeName: $VMName"
VMName="$(echo "${VMName}" | tr -d '[[:space:]]')"
RGName="$(echo "${RGName}" | tr -d '[[:space:]]')"
echo "$VMName"
if eval az vm deallocate -n "$VMName" -g "$RGName"
then
echo "command success for $VMName"
else
echo "command failed for $VMName"
fi
done < $filename